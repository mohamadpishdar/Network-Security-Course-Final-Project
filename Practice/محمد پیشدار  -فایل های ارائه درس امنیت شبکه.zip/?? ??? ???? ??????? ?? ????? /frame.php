<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<iframe src="http://www.varzesh3.com" width="400" height="300">
  <p>Your browser does not support iframes.</p>
</iframe>
<iframe src="http://www.farsnews.com" width="400" height="300">
  <p>Your browser does not support iframes.</p>
</iframe>
<iframe src="http://www.basu.ac.ir" width="400" height="300">
  <p>Your browser does not support iframes.</p>
</iframe>
<iframe src="http://127.0.0.1/adminlogin.php" width="400" height="300">
  <p>Your browser does not support iframes.</p>
</iframe>
<script>

frames[0].window.location="http://www.farsnews.com";
</script>
</html>