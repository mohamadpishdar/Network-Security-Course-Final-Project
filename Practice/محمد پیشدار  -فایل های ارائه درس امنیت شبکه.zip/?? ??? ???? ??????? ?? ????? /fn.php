<html>
<head>
<title>Frame Navigation Example</title>
</head>
<frameset COLS="*,*">
<frame NAME="left" SRC="left.php">
<frame NAME="right" SRC="about:blank">
</frameset><noframes></noframes>
</html>