<html>
<head>
<title>Frame Navigation Example</title>
</head>
<frameset COLS="*,*">
<frame NAME="left" SRC="left.html">
<frame NAME="right" SRC="about:blank">
</frameset>
</html>