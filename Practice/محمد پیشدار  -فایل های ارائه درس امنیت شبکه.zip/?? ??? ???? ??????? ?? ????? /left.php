<html>
<head>
<title>Navigation Frame</title>
</head>
<body>
<p>
Follow one of these links
to load a page into the right-hand
frame:
</p>
<ul>
<li><a HREF="#"
onClick="parent.right.location='adminlogin.php';
         window.location='Register.php'">
user Register</a>
<li><a HREF="#"
onClick="parent.right.location='register.php';
         window.location='adminlogin.php'">
admin loginَ</a>
<li><a HREF="#"
onClick="parent.right.location='sales.html';
         window.location='salesnav.html'">
Sales Dept.</a>
<li><a HREF="#"
onClick="parent.right.location='link.html'">
Other Links</a>
</ul>
</body>
</html>