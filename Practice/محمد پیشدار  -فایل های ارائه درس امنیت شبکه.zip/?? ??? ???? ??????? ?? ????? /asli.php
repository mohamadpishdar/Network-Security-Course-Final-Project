<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<?php 
if (isset($_GET['id']))
echo $_GET['id'];

?>
<body>
<div align="center">
<img src="1300760059-talab-ir.jpg" width="450" height="314" /><img src="fu4618.jpg" width="450" height="352" /> </div>
</body>
</html>